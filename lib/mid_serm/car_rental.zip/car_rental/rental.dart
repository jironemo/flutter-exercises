class Rental {
  String cname = "";
  String phoneNo = "";
  String carType = "";
  String numPassengers = "";
  String date = "";
  Rental({
    required this.cname,
    required this.phoneNo,
    required this.carType,
    required this.numPassengers,
    required this.date,
  });
}
