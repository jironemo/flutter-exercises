import 'dart:math';

import 'package:flutter/material.dart';

main() {
  runApp(MaterialApp(home: GameApp()));
}

class GameApp extends StatefulWidget {
  const GameApp({super.key});

  @override
  // ignore: library_private_types_in_public_api
  _GameAppState createState() => _GameAppState();
}

class _GameAppState extends State<GameApp> {
  int face = 0;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Dice Game"),
        centerTitle: true,
      ),
      body: Center(
          child: Column(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: [
          Image.asset("images/dice_${face}.png"),
          Text(
            "$face",
            style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
          ),
          ElevatedButton(
              onPressed: () => setState(() => Random().nextInt(6) + 1),
              child: Text("Play"))
        ],
      )),
    );
  }
}
